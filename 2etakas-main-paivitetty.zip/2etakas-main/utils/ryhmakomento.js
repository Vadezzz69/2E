const { satunnainen } = require("./satunnainen");

/**
 * /vakoilu-, /tutkimus- ja /oikeus-komennot ovat ilman alikomentoja toimivia
 * oikopolkuja: komitea valitsee itse yhden saman perheen komennoista ja
 * ajaa sen. Jäsenkomennot (esim. /ratsia, /kuulustelu) säilyvät omina
 * komentoinaan, joten tämä ei kopioi niiden toiminnallisuutta.
 *
 * Jäsenen ja ryhmäkomennon valinnan nimen on oltava sama (esim. "kayttaja"),
 * koska jäsen lukee kohteen suoraan ryhmäkomennon interaktiosta.
 */
async function ajaSatunnainenJasen(interaction, client, jasenet) {
    const nimi = satunnainen(jasenet);
    const komento = client.commands.get(nimi);

    if (!komento) {
        throw new Error(`Ryhmäkomennon jäsentä /${nimi} ei löytynyt.`);
    }

    return komento.execute(interaction, client);
}

module.exports = { ajaSatunnainenJasen };
