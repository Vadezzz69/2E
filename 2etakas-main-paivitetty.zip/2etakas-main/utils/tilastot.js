const { run, get, all } = require("./db");
const { tanaanHelsingissa, paiviaSittenHelsingissa, paivanAlkuMs } = require("./time");

function tanaan() {
    return tanaanHelsingissa();
}

// =====================================================
// VIESTIT
// =====================================================

async function kirjaaViesti(guildId, userId) {
    await run(
        `INSERT INTO message_stats (guildId, userId, date, count)
         VALUES (?, ?, ?, 1)
         ON CONFLICT(guildId, userId, date)
         DO UPDATE SET count = count + 1`,
        [guildId, userId, tanaan()]
    );
}

// =====================================================
// ÄÄNIAIKA
// =====================================================

async function lisaaAanaikaa(guildId, userId, seconds) {

    if (seconds <= 0) return;

    await run(
        `INSERT INTO voice_stats (guildId, userId, date, seconds)
         VALUES (?, ?, ?, ?)
         ON CONFLICT(guildId, userId, date)
         DO UPDATE SET seconds = seconds + excluded.seconds`,
        [guildId, userId, tanaan(), seconds]
    );

}

// =====================================================
// AKTIIVISET ÄÄNISESSIOT
// =====================================================

async function aloitaAaniSessio(guildId, userId, joinedAt = Date.now()) {

    await run(
        `INSERT OR REPLACE INTO active_voice_sessions
        (guildId, userId, joinedAt)
        VALUES (?, ?, ?)`,
        [guildId, userId, joinedAt]
    );

}

async function haeAaniSessio(guildId, userId) {

    return get(
        `SELECT *
         FROM active_voice_sessions
         WHERE guildId = ?
         AND userId = ?`,
        [guildId, userId]
    );

}

async function poistaAaniSessio(guildId, userId) {

    await run(
        `DELETE FROM active_voice_sessions
         WHERE guildId = ?
         AND userId = ?`,
        [guildId, userId]
    );

}

async function haeAktiivisetSessiotPalvelimelta(guildId) {

    return all(
        `SELECT *
         FROM active_voice_sessions
         WHERE guildId = ?`,
        [guildId]
    );

}

// =====================================================
// KOMENNOT
// =====================================================

async function kirjaaKomento(guildId, userId, command) {

    await run(
        `INSERT INTO command_usage
        (guildId, userId, command, timestamp)
        VALUES (?, ?, ?, ?)`,
        [guildId, userId, command, Date.now()]
    );

}

// =====================================================
// PÄIVÄN YKKÖSET
// =====================================================

async function aktiivisinKirjoittaja(guildId) {

    return get(
        `SELECT userId, count
         FROM message_stats
         WHERE guildId = ?
         AND date = ?
         ORDER BY count DESC
         LIMIT 1`,
        [guildId, tanaan()]
    );

}

async function aktiivisinKomennoissa(guildId) {

    const alkaen = paivanAlkuMs(tanaan());

    return get(
        `SELECT userId,
        COUNT(*) as count
        FROM command_usage
        WHERE guildId = ?
        AND timestamp >= ?
        GROUP BY userId
        ORDER BY count DESC
        LIMIT 1`,
        [guildId, alkaen]
    );

}

// =====================================================
// KÄYTTÄJÄN PÄIVÄTILASTOT
// =====================================================

async function kayttajanViestitTanaan(guildId, userId) {

    const row = await get(
        `SELECT count
         FROM message_stats
         WHERE guildId = ?
         AND userId = ?
         AND date = ?`,
        [guildId, userId, tanaan()]
    );

    return row?.count ?? 0;

}

async function kayttajanAaniTanaan(guildId, userId) {

    const row = await get(
        `SELECT seconds
         FROM voice_stats
         WHERE guildId = ?
         AND userId = ?
         AND date = ?`,
        [guildId, userId, tanaan()]
    );

    return row?.seconds ?? 0;

}

// =====================================================
// KAIKKIEN AIKOJEN TILASTOT
// =====================================================

async function kayttajanViestitYhteensa(guildId, userId) {

    const row = await get(
        `SELECT COALESCE(SUM(count),0) as total
         FROM message_stats
         WHERE guildId = ?
         AND userId = ?`,
        [guildId, userId]
    );

    return row?.total ?? 0;

}

async function kayttajanAaniYhteensa(guildId, userId) {

    const row = await get(
        `SELECT COALESCE(SUM(seconds),0) as total
         FROM voice_stats
         WHERE guildId = ?
         AND userId = ?`,
        [guildId, userId]
    );

    return row?.total ?? 0;

}

async function kayttajanKomentojaYhteensa(guildId, userId) {

    const row = await get(
        `SELECT COUNT(*) as total
         FROM command_usage
         WHERE guildId = ?
         AND userId = ?`,
        [guildId, userId]
    );

    return row?.total ?? 0;

}

async function kayttajanSuosikkiKomento(guildId, userId) {

    return get(
        `SELECT command,
        COUNT(*) as count
        FROM command_usage
        WHERE guildId = ?
        AND userId = ?
        GROUP BY command
        ORDER BY count DESC
        LIMIT 1`,
        [guildId, userId]
    );

}

// =====================================================
// "ELÄVÄT" ÄÄNITILASTOT
// Huomioivat myös juuri nyt käynnissä olevat äänisessiot,
// eikä vain jo tallennettua (suljettua) aikaa. Näin esim.
// /kayttajainfo näyttää oikean luvun vaikka kohde olisi
// parhaillaan äänikanavalla eikä ole vielä poistunut sieltä.
// =====================================================

async function elavatSessiot(guildId) {

    const rivit = await all(
        `SELECT userId, joinedAt FROM active_voice_sessions WHERE guildId = ?`,
        [guildId]
    );

    const nyt = Date.now();
    const kartta = new Map();

    for (const rivi of rivit) {
        const sekunnit = Math.max(0, Math.floor((nyt - rivi.joinedAt) / 1000));
        kartta.set(rivi.userId, sekunnit);
    }

    return kartta;

}

async function kayttajanAaniTanaanElavana(guildId, userId) {

    const [tallennettu, elavat] = await Promise.all([
        kayttajanAaniTanaan(guildId, userId),
        elavatSessiot(guildId)
    ]);

    return tallennettu + (elavat.get(userId) ?? 0);

}

async function kayttajanAaniYhteensaElavana(guildId, userId) {

    const [tallennettu, elavat] = await Promise.all([
        kayttajanAaniYhteensa(guildId, userId),
        elavatSessiot(guildId)
    ]);

    return tallennettu + (elavat.get(userId) ?? 0);

}

async function aaniListaElavana(guildId, limit = 10) {

    const [tallennettu, elavat] = await Promise.all([
        all(
            `SELECT userId, seconds FROM voice_stats WHERE guildId = ? AND date = ?`,
            [guildId, tanaan()]
        ),
        elavatSessiot(guildId)
    ]);

    const kartta = new Map(tallennettu.map(r => [r.userId, r.seconds]));

    for (const [userId, sekunnit] of elavat) {
        kartta.set(userId, (kartta.get(userId) ?? 0) + sekunnit);
    }

    return [...kartta.entries()]
        .map(([userId, seconds]) => ({ userId, seconds }))
        .sort((a, b) => b.seconds - a.seconds)
        .slice(0, limit);

}

async function aktiivisinAanikanavassaElavana(guildId) {

    const lista = await aaniListaElavana(guildId, 1);
    return lista[0] ?? null;

}

// =====================================================
// AIKAVÄLILLÄ SUODATETUT RANKINGIT
// "tanaan" / "viikko" / "kuukausi" / "kaikki"
// Kaikki perustuu message_stats/voice_stats-tauluihin, jotka
// kertyvät päivä kerrallaan eikä koskaan tyhjene — data on
// siis aina luettavissa mielivaltaisen kauas historiaan.
// =====================================================

const AIKAVALI_NIMET = {
    tanaan: "Tänään",
    viikko: "Viimeiset 7 päivää",
    kuukausi: "Viimeiset 30 päivää",
    kaikki: "Koko historia"
};

function aikavaliAlkupaiva(aikavali) {

    if (aikavali === "kaikki") return "0000-01-01";

    if (aikavali === "viikko") {
        return paiviaSittenHelsingissa(7);
    }

    if (aikavali === "kuukausi") {
        return paiviaSittenHelsingissa(30);
    }

    return tanaan();

}

async function viestiListaAikavalilla(guildId, aikavali, limit = 10) {

    const alkupaiva = aikavaliAlkupaiva(aikavali);

    return all(
        `SELECT userId, SUM(count) as count
         FROM message_stats
         WHERE guildId = ? AND date >= ?
         GROUP BY userId
         ORDER BY count DESC
         LIMIT ?`,
        [guildId, alkupaiva, limit]
    );

}

async function aaniListaAikavalilla(guildId, aikavali, limit = 10) {

    const alkupaiva = aikavaliAlkupaiva(aikavali);

    const [tallennettu, elavat] = await Promise.all([
        all(
            `SELECT userId, SUM(seconds) as seconds
             FROM voice_stats
             WHERE guildId = ? AND date >= ?
             GROUP BY userId`,
            [guildId, alkupaiva]
        ),
        elavatSessiot(guildId)
    ]);

    const kartta = new Map(tallennettu.map(r => [r.userId, r.seconds]));

    for (const [userId, sekunnit] of elavat) {
        kartta.set(userId, (kartta.get(userId) ?? 0) + sekunnit);
    }

    return [...kartta.entries()]
        .map(([userId, seconds]) => ({ userId, seconds }))
        .sort((a, b) => b.seconds - a.seconds)
        .slice(0, limit);

}

async function komentoListaAikavalilla(guildId, aikavali, limit = 10) {

    const alkuAika = aikavali === "kaikki"
        ? 0
        : paivanAlkuMs(aikavaliAlkupaiva(aikavali));

    return all(
        `SELECT userId, COUNT(*) as count
         FROM command_usage
         WHERE guildId = ? AND timestamp >= ?
         GROUP BY userId
         ORDER BY count DESC
         LIMIT ?`,
        [guildId, alkuAika, limit]
    );

}

module.exports = {

    tanaan,

    kirjaaViesti,
    lisaaAanaikaa,
    kirjaaKomento,

    aktiivisinKirjoittaja,
    aktiivisinKomennoissa,

    kayttajanViestitTanaan,
    kayttajanAaniTanaan,

    kayttajanViestitYhteensa,
    kayttajanAaniYhteensa,
    kayttajanKomentojaYhteensa,
    kayttajanSuosikkiKomento,

    aloitaAaniSessio,
    haeAaniSessio,
    poistaAaniSessio,
    haeAktiivisetSessiotPalvelimelta,

    elavatSessiot,
    kayttajanAaniTanaanElavana,
    kayttajanAaniYhteensaElavana,
    aaniListaElavana,
    aktiivisinAanikanavassaElavana,

    AIKAVALI_NIMET,
    aikavaliAlkupaiva,
    viestiListaAikavalilla,
    aaniListaAikavalilla,
    komentoListaAikavalilla

};
