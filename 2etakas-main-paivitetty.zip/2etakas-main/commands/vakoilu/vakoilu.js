const { SlashCommandBuilder } = require("discord.js");
const { ajaSatunnainenJasen } = require("../../utils/ryhmakomento");

// Samaan perheeseen kuuluvat itsenäiset komennot (kaikki ottavat "kohde"-kohteen).
const JASENET = ["vakoile", "report", "wanted"];

module.exports = {
    JASENET,

    data: new SlashCommandBuilder()
        .setName("vakoilu")
        .setDescription("Komitea valitsee itse vakoilutavan: valvontaraportti, tilastoraportti tai etsintäkuulutus.")
        .addUserOption(option =>
            option.setName("kohde").setDescription("Vakoilun kohde").setRequired(true)
        ),

    async execute(interaction, client) {
        return ajaSatunnainenJasen(interaction, client, JASENET);
    }
};
